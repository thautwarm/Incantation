from flowpython.fp import foreach, groupby, andThen, compose, flow_map, flatten, fastmap
__version__ = 0.1
__author__ = "thautwarm"
__license__ = "MIT"


